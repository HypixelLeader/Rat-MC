package run.hypixel.dupe.exception;

public class WebhookException extends WebhookExce{

	public WebhookException() {
		super("Your webhook has encountered an error. Is it invalid?");
	}

}
