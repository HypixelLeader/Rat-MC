package run.hypixel.dupe.exception;

public class WebhookExce extends RuntimeException{
	
	public WebhookExce(String msg) {
		super(msg);
	}

}
