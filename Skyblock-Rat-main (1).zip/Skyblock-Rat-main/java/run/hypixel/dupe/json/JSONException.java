package run.hypixel.dupe.json;

public class JSONException extends Exception {
	
	public JSONException(String s) {
        super(s);
    }

}
