# Hypixel Skyblock RAT / Logger v1.2

Im absolutely sick of FreeMoneySkid (FreeMoneyHub) Stealing my rat and claiming its his so im going
to release it for free. Along with I like making RATs
EDIT: I had to make this github friendly so no more bad n words!

Discord: CustomPayload#1337

You can now easily add webhooks if you use pastebin in Hooks374!

# What does it grab?

**What it grabs and Features:**
- Discord Token:
    [!] Has Nitro
    [!] Has Billing
    [!] Email
    [!] Phone
- Minecraft Session
- Important Pc Files
- Advanced Logging System
- User Scripts
- Ransomware
- File Downloader
- File Executor
- File Spammer
- File Deleter
- Advanced and Easy Webhooks
- IP Grabber
- OS Grabber
- HWID Grabber
- PC Screenshot
- HaveIBeenPwned Checker
- Luyten Crasher

# How to login to the minecraft session

Go to your **.minecraft** folder and go to the "version" folder, Then make sure you have 1.8.9 optifine installed (What I used) (I use the HD_U_M5 version)
and then you go to the 1.8.9 optifine version instance and edit the .json file. Where you see **"minecraftArguments":** you have to change **--username** field to what the
username is of the player (e.g --username CustomPayload) and change the **--uuid** field to the players uuid, and most important change the **--accessToken** to the players
Session and then make sure you close minecraft (it might not close correctly so go to your task manager and in background tasks and terminate Minecraft Launcher)
and then start it up again, after that launch up the minecraft instance you used to change the json and you will login!

# Extra Information

**This rat is currently built in 1.8.9 forge minecraft!**

You are free to edit the code but leave my watermark on there please

Undetectable trading method on my github
(a.k.a auction transfering :trollface:)

(Totally Educational!!!!!!!!!)
